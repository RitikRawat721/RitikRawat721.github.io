# Lorena — Psychologist Portfolio (Vite + React)

This is a ready-to-run React (Vite) portfolio site for a psychologist. It includes:

- Home page with About, Qualifications, Benefits, HelpCards, Services, Blog showcase, Contact form
- Blog page and Resources page
- Admin page (protected by a simple password) to publish blogs and add resources
- Contact form that sends email via EmailJS (client-side)
- Responsive navbar with hamburger for mobile
- Animated calm background

## Quick start

1. Unzip the project and `cd` into the folder

2. Install dependencies:

```bash
npm install
```

3. Copy `.env.example` to `.env` and set values (EmailJS IDs and optional admin password)

4. Start dev server:

```bash
npm run dev
```

Open http://localhost:5173

## Admin

- Default admin password is `StrongPassword123` (set in `.env` as `VITE_ADMIN_PASSWORD`)
- Admin login stores a localStorage flag `isAdmin` — this is a simple demo. For production use a real auth provider.

## Contact form

Uses EmailJS to send messages directly from the browser.
1. Create an EmailJS account at https://www.emailjs.com
2. Create a service (e.g. Gmail), a template with variables `from_name`, `from_email`, `message` and set the template ID.
3. Set the `VITE_EMAILJS_SERVICE_ID`, `VITE_EMAILJS_TEMPLATE_ID`, `VITE_EMAILJS_USER_ID` values in `.env`

## Blog & Resources storage

For this demo, blog posts and resources are saved to `localStorage`. In production you'll want to use a backend or headless CMS (Supabase, Firebase, or a database with API).

## Notes about dependencies & compatibility

- React 18 + Vite ✅
- Tailwind CSS 4.x configured ✅
- Framer Motion ✅
- emailjs-com (client-side email) ✅

If you want a version with a secure backend (database + real auth), I can provide a Next.js + Prisma version.

---

Replace `public/doctor.jpg` with a real photo of Lorena and update the contact details in `src/components/Footer.jsx`.
