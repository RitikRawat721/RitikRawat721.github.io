import React from 'react'
export default function Footer(){
  return (
    <footer className='mt-12 py-8 bg-white/90'>
      <div className='max-w-6xl mx-auto px-6 text-center text-sm text-gray-700'>
        <div>Contact: +34 612 345 678 • hello@lorena.com • WhatsApp</div>
        <div className='mt-2'>© {new Date().getFullYear()} Lorena — All rights reserved.</div>
      </div>
    </footer>
  )
}
