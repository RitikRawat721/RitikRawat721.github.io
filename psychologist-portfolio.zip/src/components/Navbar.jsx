import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { FaBars, FaTimes } from 'react-icons/fa'
import { motion } from 'framer-motion'

export default function Navbar(){
  const [open, setOpen] = useState(false)
  return (
    <motion.nav className='fixed w-full z-40 bg-white/60 backdrop-blur-md' initial={{y:-50, opacity:0}} animate={{y:0, opacity:1}}>
      <div className='max-w-6xl mx-auto flex items-center justify-between p-4'>
        <div className='flex items-center gap-3'>
          <div className='w-10 h-10 rounded-full bg-[var(--primary)] flex items-center justify-center'>
            <img src='/logo.svg' alt='logo' className='w-8 h-8' />
          </div>
          <div className='hidden md:block font-semibold text-[var(--brand)]'>Lorena — Psychologist</div>
        </div>
        <div className='hidden md:flex items-center gap-6'>
          <a href='#about' className='hover:underline'>About</a>
          <a href='#services' className='hover:underline'>Services</a>
          <a href='#contact' className='hover:underline'>Contact</a>
          <Link to='/blog'>Blog</Link>
          <Link to='/resources'>Resources</Link>
          <Link to='/login' className='px-3 py-1 rounded-md border border-[var(--brand)] text-[var(--brand)]'>Admin</Link>
        </div>
        <button className='md:hidden' onClick={()=>setOpen(!open)} aria-label='menu'>
          {open ? <FaTimes/> : <FaBars/>}
        </button>
      </div>
      {open && (
        <div className='md:hidden bg-white/80 p-4'>
          <a href='#about' className='block py-2'>About</a>
          <a href='#services' className='block py-2'>Services</a>
          <a href='#contact' className='block py-2'>Contact</a>
          <Link to='/blog' className='block py-2'>Blog</Link>
          <Link to='/resources' className='block py-2'>Resources</Link>
          <Link to='/login' className='block py-2'>Admin</Link>
        </div>
      )}
    </motion.nav>
  )
}
