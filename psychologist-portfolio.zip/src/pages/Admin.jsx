import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'

export default function Admin(){
  const navigate = useNavigate()
  const [title, setTitle] = useState('')
  const [excerpt, setExcerpt] = useState('')
  const [rtitle, setRtitle] = useState('')
  const [rurl, setRurl] = useState('')
  const [rdesc, setRdesc] = useState('')

  useEffect(()=>{
    if (!localStorage.getItem('isAdmin')) navigate('/login')
  }, [])

  function publish(e){
    e.preventDefault()
    const posts = JSON.parse(localStorage.getItem('posts')||'[]')
    posts.unshift({ title, excerpt, createdAt: new Date().toLocaleString() })
    localStorage.setItem('posts', JSON.stringify(posts))
    setTitle(''); setExcerpt('')
    alert('Post saved')
  }

  function saveResource(e){
    e.preventDefault()
    const res = JSON.parse(localStorage.getItem('resources')||'[]')
    res.unshift({ title: rtitle, url: rurl, desc: rdesc, createdAt: new Date().toLocaleString() })
    localStorage.setItem('resources', JSON.stringify(res))
    setRtitle(''); setRurl(''); setRdesc('')
    alert('Resource saved')
  }

  function logout(){ localStorage.removeItem('isAdmin'); navigate('/') }

  return (
    <div className='max-w-4xl mx-auto px-6 py-12'>
      <div className='flex justify-between items-center mb-6'>
        <h1 className='text-2xl font-bold text-[var(--brand)]'>Admin panel</h1>
        <button onClick={logout} className='px-3 py-1 border rounded'>Logout</button>
      </div>

      <section className='card mb-6'>
        <h3 className='font-semibold mb-2'>Create blog post</h3>
        <form onSubmit={publish} className='grid gap-2'>
          <input value={title} onChange={e=>setTitle(e.target.value)} placeholder='Title' className='p-2 border rounded' />
          <textarea value={excerpt} onChange={e=>setExcerpt(e.target.value)} placeholder='Excerpt' className='p-2 border rounded' />
          <button className='px-4 py-2 bg-[var(--brand)] text-white rounded'>Publish</button>
        </form>
      </section>

      <section className='card'>
        <h3 className='font-semibold mb-2'>Add resource</h3>
        <form onSubmit={saveResource} className='grid gap-2'>
          <input value={rtitle} onChange={e=>setRtitle(e.target.value)} placeholder='Title' className='p-2 border rounded' />
          <input value={rurl} onChange={e=>setRurl(e.target.value)} placeholder='URL' className='p-2 border rounded' />
          <textarea value={rdesc} onChange={e=>setRdesc(e.target.value)} placeholder='Description' className='p-2 border rounded' />
          <button className='px-4 py-2 bg-[var(--brand)] text-white rounded'>Save resource</button>
        </form>
      </section>
    </div>
  )
}
