import React, { useState, useEffect } from 'react'

export default function Blog(){
  const [posts, setPosts] = useState([])
  useEffect(()=>{
    const saved = JSON.parse(localStorage.getItem('posts')||'[]')
    setPosts(saved)
  }, [])

  return (
    <div className='max-w-6xl mx-auto px-6 py-12'>
      <h1 className='text-2xl font-bold text-[var(--brand)] mb-6'>Blog</h1>
      <div className='grid gap-4'>
        {posts.length===0 && <div className='card'>No posts yet.</div>}
        {posts.map((p,i)=> (
          <article key={i} className='card'>
            <h4 className='font-semibold'>{p.title}</h4>
            <p className='text-sm text-gray-600 mt-2'>{p.excerpt}</p>
            <div className='mt-2 text-xs text-gray-500'>Posted: {p.createdAt}</div>
          </article>
        ))}
      </div>
    </div>
  )
}
