import React from 'react'
import About from '../sections/About'
import Qualifications from '../sections/Qualifications'
import Benefits from '../sections/Benefits'
import HelpCards from '../sections/HelpCards'
import Services from '../sections/Services'
import BlogShowcase from '../sections/BlogShowcase'
import ContactForm from '../sections/ContactForm'

export default function Home(){
  return (
    <div className='pt-24'>
      <section className='max-w-6xl mx-auto px-6 py-12'>
        <About />
      </section>
      <section className='max-w-6xl mx-auto px-6 py-6'>
        <Qualifications />
      </section>
      <section className='max-w-6xl mx-auto px-6 py-6'>
        <Benefits />
      </section>
      <section className='max-w-6xl mx-auto px-6 py-6'>
        <HelpCards />
      </section>
      <section id='services' className='max-w-6xl mx-auto px-6 py-6'>
        <Services />
      </section>
      <section className='max-w-6xl mx-auto px-6 py-6'>
        <BlogShowcase />
      </section>
      <section id='contact' className='max-w-6xl mx-auto px-6 py-6'>
        <ContactForm />
      </section>
    </div>
  )
}
