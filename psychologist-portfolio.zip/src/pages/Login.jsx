import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'

export default function Login(){
  const [pwd, setPwd] = useState('')
  const navigate = useNavigate()

  function handleSubmit(e){
    e.preventDefault()
    const ADMIN_PWD = import.meta.env.VITE_ADMIN_PASSWORD || 'StrongPassword123'
    if (pwd === ADMIN_PWD){
      localStorage.setItem('isAdmin', 'true')
      navigate('/admin')
    } else {
      alert('Wrong password')
    }
  }

  return (
    <div className='min-h-[60vh] flex items-center justify-center p-6'>
      <form onSubmit={handleSubmit} className='card w-full max-w-md'>
        <h2 className='text-2xl font-bold text-[var(--brand)] mb-4'>Admin login</h2>
        <input type='password' value={pwd} onChange={e=>setPwd(e.target.value)} placeholder='Password' className='p-2 border rounded w-full' />
        <button className='mt-4 px-4 py-2 bg-[var(--brand)] text-white rounded'>Enter</button>
        <p className='mt-2 text-sm text-gray-600'>Default demo password: StrongPassword123</p>
      </form>
    </div>
  )
}
