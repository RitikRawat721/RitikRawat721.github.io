import React, { useState, useEffect } from 'react'
export default function Resources(){
  const [resources, setResources] = useState([])
  useEffect(()=>{
    const saved = JSON.parse(localStorage.getItem('resources')||'[]')
    setResources(saved)
  }, [])
  return (
    <div className='max-w-6xl mx-auto px-6 py-12'>
      <h1 className='text-2xl font-bold text-[var(--brand)] mb-6'>Resources</h1>
      <div className='grid sm:grid-cols-2 gap-4'>
        {resources.length===0 && <div className='card'>No resources yet.</div>}
        {resources.map((r,i)=> (
          <a key={i} href={r.url} target='_blank' rel='noreferrer' className='card'>
            <h4 className='font-semibold'>{r.title}</h4>
            <p className='text-sm text-gray-600 mt-2'>{r.desc}</p>
            <div className='mt-2 text-xs text-gray-500'>Added: {r.createdAt}</div>
          </a>
        ))}
      </div>
    </div>
  )
}
