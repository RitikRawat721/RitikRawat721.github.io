import React from 'react'
import { motion } from 'framer-motion'

export default function About(){
  return (
    <motion.div className='card flex flex-col md:flex-row items-center gap-6' initial={{opacity:0}} animate={{opacity:1}}>
      <div className='w-full md:w-1/3'>
        <img src='/doctor.jpg' alt='Lorena' className='rounded-xl w-full h-auto object-cover' />
      </div>
      <div className='w-full md:w-2/3'>
        <h2 className='text-2xl font-bold text-[var(--brand)]'>About Lorena</h2>
        <p className='mt-3 text-gray-700'>Lorena is a licensed psychologist specializing in CBT, mindfulness and trauma-informed care. She supports clients with anxiety, depression and life transitions through evidence-based therapy tailored to each person's needs.</p>
      </div>
    </motion.div>
  )
}
