import React from 'react'
import { motion } from 'framer-motion'

export default function Benefits(){
  const items = [
    {title:'Reduce Anxiety', desc:'Practical skills to manage worry and panic.'},
    {title:'Improve Mood', desc:'Behavioral activation and tools to lift mood.'},
    {title:'Better Relationships', desc:'Communication and boundary work.'},
    {title:'Trauma Recovery', desc:'Paced, supportive trauma care.'}
  ]
  return (
    <div>
      <h3 className='text-xl font-bold text-[var(--brand)] mb-4'>Benefits of Therapy</h3>
      <div className='flex overflow-x-auto gap-4 py-2'>
        {items.map((it,i)=> (
          <motion.div key={i} className='min-w-[22rem] card flex-shrink-0' whileHover={{scale:1.02}} transition={{type:'spring'}}>
            <h4 className='font-semibold'>{it.title}</h4>
            <p className='text-sm text-gray-600 mt-2'>{it.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  )
}
