import React from 'react'
import { useNavigate } from 'react-router-dom'
export default function BlogShowcase(){
  const navigate = useNavigate()
  const posts = [
    {id:1, title:'Managing Anxiety with Small Steps', excerpt:'Practical tips you can use today.'},
    {id:2, title:'Sleep and Mental Health', excerpt:'How sleep affects mood and recovery.'}
  ]
  return (
    <div>
      <h3 className='text-xl font-bold text-[var(--brand)] mb-4'>From the blog</h3>
      <div className='grid md:grid-cols-2 gap-4'>
        {posts.map(p=> (
          <article key={p.id} className='card cursor-pointer' onClick={()=>navigate('/blog')}>
            <h4 className='font-semibold'>{p.title}</h4>
            <p className='text-sm text-gray-600 mt-2'>{p.excerpt}</p>
          </article>
        ))}
      </div>
    </div>
  )
}
