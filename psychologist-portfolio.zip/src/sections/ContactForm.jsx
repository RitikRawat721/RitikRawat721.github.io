import React, { useState } from 'react'
import emailjs from 'emailjs-com'

export default function ContactForm(){
  const [form, setForm] = useState({name:'', email:'', message:''})
  const [status, setStatus] = useState('')

  async function handleSubmit(e){
    e.preventDefault()
    setStatus('sending')
    try{
      const SERVICE_ID = import.meta.env.VITE_EMAILJS_SERVICE_ID || 'YOUR_SERVICE_ID'
      const TEMPLATE_ID = import.meta.env.VITE_EMAILJS_TEMPLATE_ID || 'YOUR_TEMPLATE_ID'
      const USER_ID = import.meta.env.VITE_EMAILJS_USER_ID || 'YOUR_USER_ID'
      await emailjs.send(SERVICE_ID, TEMPLATE_ID, {
        from_name: form.name,
        from_email: form.email,
        message: form.message
      }, USER_ID)
      setStatus('sent')
      setForm({name:'', email:'', message:''})
    }catch(err){
      console.error(err)
      setStatus('error')
    }
  }

  return (
    <div className='card'>
      <h3 className='text-xl font-bold text-[var(--brand)] mb-4'>Contact</h3>
      <form onSubmit={handleSubmit} className='grid gap-3'>
        <input required value={form.name} onChange={e=>setForm({...form, name:e.target.value})} placeholder='Your name' className='p-2 border rounded' />
        <input required value={form.email} onChange={e=>setForm({...form, email:e.target.value})} placeholder='Your email' className='p-2 border rounded' />
        <textarea required value={form.message} onChange={e=>setForm({...form, message:e.target.value})} placeholder='How can I help?' className='p-2 border rounded h-36' />
        <button type='submit' className='px-4 py-2 bg-[var(--brand)] text-white rounded'>Send message</button>
        {status==='sending' && <div className='text-sm text-gray-600'>Sending...</div>}
        {status==='sent' && <div className='text-sm text-green-600'>Message sent — Lorena will reply soon.</div>}
        {status==='error' && <div className='text-sm text-red-600'>Error sending message. Check console.</div>}
      </form>
    </div>
  )
}
