import React from 'react'
import { motion } from 'framer-motion'
export default function HelpCards(){
  const list = [
    {title:'Anxiety', desc:'Tools to manage panic and chronic worry.'},
    {title:'Depression', desc:'Behavioral activation and mood tracking.'},
    {title:'Trauma', desc:'Trauma-informed approaches.'},
    {title:'Relationship Issues', desc:'Communication and boundary work.'}
  ]
  return (
    <div>
      <h3 className='text-xl font-bold text-[var(--brand)] mb-4'>How Lorena Can Help</h3>
      <div className='grid sm:grid-cols-2 lg:grid-cols-4 gap-4'>
        {list.map((l,i)=> (
          <motion.div key={i} className='card' whileHover={{y:-6}}>
            <h4 className='font-semibold'>{l.title}</h4>
            <p className='text-sm text-gray-600 mt-2'>{l.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  )
}
