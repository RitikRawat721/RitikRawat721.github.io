import React from 'react'

export default function Qualifications(){
  const list = [
    'MSc Clinical Psychology — University X',
    'Licensed Psychologist (PD-12345)',
    'Certified CBT Practitioner',
    '10+ years clinical experience'
  ]
  return (
    <div className='grid md:grid-cols-2 gap-4'>
      {list.map((l, i)=> (
        <div key={i} className='card'>
          <h3 className='font-semibold text-[var(--brand)]'>{l.split('—')[0]}</h3>
          <p className='text-sm text-gray-600 mt-2'>{l.includes('—')? l.split('—')[1] : ''}</p>
        </div>
      ))}
    </div>
  )
}
