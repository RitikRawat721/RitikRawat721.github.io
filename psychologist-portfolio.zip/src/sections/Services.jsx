import React from 'react'
import { motion } from 'framer-motion'

export default function Services(){
  return (
    <div>
      <h3 className='text-xl font-bold text-[var(--brand)] mb-4'>Services & Pricing</h3>
      <div className='grid md:grid-cols-3 gap-4'>
        <motion.div className='card' whileHover={{scale:1.02}}>
          <h4 className='font-semibold'>Individual Session</h4>
          <p className='mt-2'>50 minute therapy session</p>
          <div className='mt-4 text-xl font-bold text-[var(--brand)]'>50 €</div>
        </motion.div>

        <motion.div className='card' whileHover={{scale:1.02}}>
          <h4 className='font-semibold'>Couples Session</h4>
          <p className='mt-2'>50 minute couples session</p>
          <div className='mt-4 text-xl font-bold text-[var(--brand)]'>50 €</div>
        </motion.div>

        <a className='card text-center' href='https://example-doctor.com' target='_blank' rel='noreferrer'>
          <h4 className='font-semibold'>Referral — Dr. Martínez</h4>
          <p className='mt-2'>For specialised trauma-focused EMDR and other interventions.</p>
          <div className='mt-4 underline text-sm text-gray-600'>Visit referral</div>
        </a>
      </div>
    </div>
  )
}
